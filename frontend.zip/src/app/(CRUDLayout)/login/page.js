import UserLoginPage from "@/components/User/UserLoginPage";
export default function LoginPage() {
  return <UserLoginPage />;
}
