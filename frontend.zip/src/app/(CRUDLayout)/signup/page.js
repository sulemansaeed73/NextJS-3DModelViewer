import SignupPage from "@/components/User/UserSignupPage";

export default function Signup() {
  return <SignupPage />;
}
