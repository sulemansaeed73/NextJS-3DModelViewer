import Header from "@/components/Header";
export default function HeadderComponent() {
  return <Header />;
}
