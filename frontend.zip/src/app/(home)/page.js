import Home from "@/components/HomePage";

export default function HomePage() {
  return <Home />;
}
