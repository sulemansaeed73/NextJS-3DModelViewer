import UploadAutoCad from "@/components/UploadAutoCad";

export default function Page() {
  return <UploadAutoCad />
}
